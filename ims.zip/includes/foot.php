<!-- Footer Section -->
<footer>
	<p>&copy; 2024 MyWebsite. All Rights Reserved.</p>
	<p>Website designed and developed by: Suraj Bastola</p>
</footer>

<script src = "assets/js/script.js"></script>
</body>
</html>
