<?php

require __DIR__ . '/../vendor/autoload.php';

use MongoDB\Client;
use MongoDB\Driver\ServerApi;

// MongoDB connection URI
$uri = 'mongodb+srv://bastolasuraj:nQ5F5gvAaPNksmHn@ims.2fci6.mongodb.net/?retryWrites=true&w=majority';

if (!$uri) {
    die('MONGODB_URI is not set or invalid.');
}

// Set the version of the Stable API on the client
$apiVersion = new ServerApi(ServerApi::V1);

try {
    // Create a new client and connect to the server
    $client = new Client($uri, [], ['serverApi' => $apiVersion]);

    // Ping the server to confirm the connection
    $client->selectDatabase('admin')->command(['ping' => 1]);

    // Set your database
    $database = $client->imsDB; // Replace 'imsDB' with your actual database name

    // Get the collection name dynamically from the page
    $collectionName = isset($collectionName) ? $collectionName : 'imsCollection'; // Default collection
    $collection = $database->$collectionName; // Select the collection dynamically

} catch (\Exception $e) {
    printf("Connection error: %s", $e->getMessage());
}
?>
