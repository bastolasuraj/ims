<?php
	include 'includes/head.php';
?>

	<!-- Main Content -->
	<div class = "container">
		<h2>Welcome to SB Logical Inventory Management Service</h2>
	</div>

<?php
	include 'includes/foot.php';
?>